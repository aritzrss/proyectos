#include <stdio.h>
#include <winsock2.h>
#include <stdlib.h>
#include "../hFilesCliente/comunicacion.h"

#define PORT 8080
#define BUFFER_SIZE 1024

//gcc cFiles/main.c -o cliente -lws2_32

// ESTADOS DEL FLUJO ENTRE MENUS
#define menu_inicio 0
#define menu_registro_alias 11
#define menu_registro_contrasena 12
#define menu_login_alias 21
#define menu_login_contrasena 22
#define menu_principal 3
#define menu_posibilidades_Reaccion 4
#define menu_posibilidades_Simon 5
#define menu_dificultades_Topo 6
#define menu_topo_facil 7
#define menu_topo_medio 8
#define menu_topo_difil 9
#define menu_admin 10

#define salir_completo -1

int recv_size;

void sendCode(SOCKET sock, int code) {
    send(sock, (const char*)&code, sizeof(code), 0);
    printf("Codigo %d enviado\n", code);
}

void clearInputBuffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

void sendCode_Y_String(SOCKET sock, int code, const char *alias) {
    printf("1");
    if (send(sock, (const char*)&code, sizeof(code), 0) == -1) {
        perror("Error enviando el código");
        return;
    }
    printf("Código %d enviado\n", code);

    int alias_len = strlen(alias) + 1;
    if (send(sock, alias, alias_len, 0) == -1) {
        perror("Error enviando el alias");
        return;
    }
    printf("Mensaje '%s' enviado\n", alias);
}

void procesar_buffer(char *buffer, int recv_size) {
    buffer[recv_size] = '\0';
    printf("%s", buffer);
}

void solicitar(SOCKET sock, int code, char *buffer) {
    memset(buffer, 0, BUFFER_SIZE);
    sendCode(sock, code);
    recv_size = recv(sock, buffer, BUFFER_SIZE - 1, 0);
    if (recv_size > 0) {
        procesar_buffer(buffer, recv_size);
    } else if (recv_size == 0) {
        perror("La longitud de lo recibido ha sido 0");
    } else {
        perror("Error recibiendo datos del servidor");
    }
}

int main() {
    WSADATA wsa;
    SOCKET sock;
    struct sockaddr_in serv_addr;
    char server_ip[16] = "172.26.33.97";
    char buffer[BUFFER_SIZE];
    int currentMenu = menu_inicio;
    int eleccionCliente;
    char* temp = (char*) malloc(sizeof(char)*BUFFER_SIZE);

    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("Failed. Error Code : %d\n", WSAGetLastError());
        return 1;
    }

    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        printf("Could not create socket : %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    serv_addr.sin_addr.s_addr = inet_addr(server_ip);

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("Connection Failed\n");
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    while (currentMenu != salir_completo) {
        switch (currentMenu) {
            case menu_inicio:
                solicitar(sock, MENU_INICIO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        currentMenu = menu_registro_alias;
                        break;
                    case 2:
                        currentMenu = menu_login_alias;
                        break;
                    case 3:
                        currentMenu = menu_admin;
                        break;
                    case 4:
                        currentMenu = salir_completo;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_admin:
                sendCode(sock, MENU_ADMIN);
                currentMenu = menu_principal;
                break;

            case menu_registro_alias:
                solicitar(sock, MENU_REGISTRO_ALIAS, buffer);
                scanf("%15s", temp);

                if (temp == "") {
                    perror("Error al leer el alias");
                    currentMenu = menu_inicio;
                    break;
                }
                temp[strcspn(temp, "\n")] = '\0';
                sendCode_Y_String(sock, ENVIO_ALIAS_REGISTRO, temp);
                currentMenu = menu_registro_contrasena;
                temp = NULL;
                break;

            case menu_registro_contrasena:
                memset(buffer, 0, BUFFER_SIZE);
                recv(sock, buffer, BUFFER_SIZE - 1, 0);
                printf("%s", buffer);
                solicitar(sock, MENU_REGISTRO_CLAVE, buffer);
                scanf("%s", temp);
                printf("1");
                sendCode_Y_String(sock, ENVIO_CONTRASENYA_REGISTRO, temp);
                printf("2");
                
                currentMenu = menu_principal;
                free(temp);
                break;

            case menu_login_alias:
                solicitar(sock, MENU_LOGIN_ALIAS, buffer);
                scanf("%15s", temp);
                if(temp == "") {
                    perror("Error al leer el alias");
                    currentMenu = menu_inicio;
                    break;
                }

                temp[strcspn(temp, "\n")] = '\0';
                sendCode_Y_String(sock, ENVIO_ALIAS_LOGIN, temp);
                currentMenu = menu_login_contrasena;
                free(temp);
                break;

            case menu_login_contrasena:
                scanf("%15s", temp);
                if (temp == "") {
                    perror("Error al leer la clave");
                    currentMenu = menu_inicio;
                    break;
                }
                temp[strcspn(temp, "\n")] = '\0';
                sendCode_Y_String(sock, ENVIO_CONTRASENYA_LOGIN, temp);
                currentMenu = menu_principal;
                free(temp);
                break;

            case menu_principal:
                solicitar(sock, MENU_PRINCIPAL, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        currentMenu = menu_posibilidades_Reaccion;
                        break;
                    case 2:
                        currentMenu = menu_posibilidades_Simon;
                        break;
                    case 3:
                        currentMenu = menu_dificultades_Topo;
                        break;
                    case 4:
                        currentMenu = menu_inicio;
                        break;

                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_posibilidades_Reaccion:
                solicitar(sock, MENU_OPCIONES_JUEGO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        solicitar(sock, SOLICITUD_PUNTUACIONES_USUARIO_REACCION, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 2:
                        solicitar(sock, SOLICITUD_MEJORES_PUNTUACIONES_REACCION, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 3:
                        solicitar(sock, JUEGO_TIEMPO_REACCION, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        currentMenu = menu_principal;
                        break;
                    case 4:
                        currentMenu = menu_principal;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_posibilidades_Simon:
                solicitar(sock, MENU_OPCIONES_JUEGO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        solicitar(sock, SOLICITUD_PUNTUACIONES_USUARIO_SIMON, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Simon;
                        free(temp);
                        break;
                    case 2:
                        solicitar(sock, SOLICITUD_MEJORES_PUNTUACIONES_SIMON, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Simon;
                        free(temp);
                        break;
                    case 3:
                        solicitar(sock, JUEGO_SIMON_SAYS, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        currentMenu = menu_principal;
                        break;
                    case 4:
                        currentMenu = menu_principal;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_dificultades_Topo:
                solicitar(sock, MENU_DIFICULTADES_TOPO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        currentMenu = menu_topo_facil;
                        break;
                    case 2:
                        currentMenu = menu_topo_medio;
                        break;
                    case 3:
                        currentMenu = menu_topo_difil;
                        break;
                    case 4:
                        currentMenu = menu_principal;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_topo_facil:
                solicitar(sock, MENU_OPCIONES_JUEGO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        solicitar(sock, SOLICITUD_PUNTUACIONES_USUARIO_TOPO_F, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 2:
                        solicitar(sock, SOLICITUD_MEJORES_PUNTUACIONES_TOPO_F, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 3:
                        solicitar(sock, DIFICULTAD_FACIL, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        currentMenu = menu_principal;
                        break;
                    case 4:
                        currentMenu = menu_principal;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_topo_medio:
                solicitar(sock, MENU_OPCIONES_JUEGO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        solicitar(sock, SOLICITUD_PUNTUACIONES_USUARIO_TOPO_M, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 2:
                        solicitar(sock, SOLICITUD_MEJORES_PUNTUACIONES_TOPO_F, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 3:
                        solicitar(sock, DIFICULTAD_NORMAL, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        currentMenu = menu_principal;
                        break;
                    case 4:
                        currentMenu = menu_principal;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;

            case menu_topo_difil:
                solicitar(sock, MENU_OPCIONES_JUEGO, buffer);
                memset(buffer, 0, BUFFER_SIZE);
                scanf("%d", &eleccionCliente);

                switch (eleccionCliente) {
                    case 1:
                        solicitar(sock, SOLICITUD_MEJORES_PUNTUACIONES_TOPO_D, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 2:
                        solicitar(sock, SOLICITUD_MEJORES_PUNTUACIONES_TOPO_D, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        printf("\n Si deseo hacer cualquier otra cosa, pulse cualquier tecla:");
                        scanf("%s", temp);
                        currentMenu = menu_posibilidades_Reaccion;
                        free(temp);
                        break;
                    case 3:
                        solicitar(sock, DIFICULTAD_DIFICIL, buffer);
                        memset(buffer, 0, BUFFER_SIZE);
                        currentMenu = menu_principal;
                        break;
                    case 4:
                        currentMenu = menu_principal;
                        break;
                    default:
                        printf("Elección inválida, prueba de nuevo. \n");
                }
                break;
        }
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}
