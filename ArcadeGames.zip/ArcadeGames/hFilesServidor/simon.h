#ifndef _SIMON_H_
#define _SIMON_H_

#include "Usuario.h"

int rand_range(int min, int max);

void print_instructions();

void generate_display_sequence(int* sequence, int length);

void get_player_input(int* player_sequence, int length);

int compare_sequences(int* sequence, int* player_sequence, int length);

int simon(Persona usuario, int moves, int lives, int score);

#endif
