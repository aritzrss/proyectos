#ifndef MENU_H
#define MENU_H

#include "Usuario.h"

void mostrarMenuInicio(int command, int clientSocket);
void mostrarMenuPrincipal(Persona usuario, int command, int clientSocket);
void mostrarOpcionesJuego(Persona usuario, int command, int clientSocket);
void mostrarDificultadesTopo(Persona usuario, int command, int clientSocket);

#endif