#ifndef _SIMON_H_
#define _SIMON_H_

// Enumeración para los niveles de severidad
typedef enum {
    INFO,
    DEBUG,
    WARNING,
    ERROR
} LogLevel;

char* get_timestamp();

void log_message(LogLevel level, const char *format, ...);

#endif