#ifndef DATABASE_H
#define DATABASE_H

#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <string>
#include "sqlite3.h"
#include "Usuario.h"
#include <vector>


extern sqlite3 *db;

struct Puntuacion {
    std::string alias;
    float puntuacion;
    std::string fecha;
};

void abrirBaseDatos();
void cerrarBaseDatos();
void crearTablaUsuarios();
void crearTablaPuntuacion();
void crearTablaModoJuego();
void crearTablaTipoPuntuacion();
void insertarUsuario(Persona usuario);
int findIdUsu(Persona usuario);
void insertarPuntuacion(Persona usuario, int codigo_juego, char* puntuacion);
void insertarTipoPuntuacion();
void insertarModoJuego();
Persona obtenerUsuarioPorAlias(const char *alias);
void inicializarBaseDatos();
void mostrarPuntuacionesJuego(int codigo, int clienteSocket);
void mostrarPuntuacionesUsuario(Persona usuario, int codigo, int clienteSocket);
void enviarPuntuaciones(const std::vector<Puntuacion> &puntuaciones, int clienteSocket);
std::vector<Puntuacion> obtenerTopPuntuaciones(int codigoJuego, sqlite3* db);
std::vector<Puntuacion> obtenerTopPuntuacionesUsuario(Persona usuario, sqlite3* db);
#endif
