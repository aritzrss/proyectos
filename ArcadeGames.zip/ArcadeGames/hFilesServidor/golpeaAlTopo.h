#ifndef GOLPEALTOPO_H
#define GOLPEALTOPO_H

#include "Usuario.h"

void empezarGolpeaAlTopo(Persona Usuario);
void juegoGolpeaAlTopo(Persona usuario, int dificultad);

/**/
#endif