#ifndef MAIN_H
#define MAIN_H

#include "Usuario.h"

/*  typedef struct {
    char alias[21];
    char nombre[21];
    char contrasena[21];
} Persona;  */


void mostrarMenuInicio();


void mostrarMenuPrincipal(Persona usuario);


#endif

