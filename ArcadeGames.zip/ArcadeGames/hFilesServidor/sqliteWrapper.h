#ifndef SQLITEWRAPPER_H
#define SQLITEWRAPPER_H

#include <string>
#include "sqlite3.h"

class SQLiteWrapper {
public:
    SQLiteWrapper(const std::string& dbFileName);
    ~SQLiteWrapper();

    bool execute(const std::string& sql);
    bool query(const std::string& sql, int (*callback)(void*, int, char**, char**), void* data);

private:
    sqlite3* db;
};

#endif