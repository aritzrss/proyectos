#ifndef _TEMP_R_H_
#define _TEMP_R_H_

#include <iostream>
#include <ctime>
#include "Usuario.h"

// Declaración de la función getch
int getch();

void encenderLED(int led);
void apagarLEDs();
void reaccion(Persona usuario);

#endif // _TEMP_R_H_
