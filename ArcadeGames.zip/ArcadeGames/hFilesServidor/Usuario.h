#ifndef USER_H
#define USER_H

typedef struct{
    char alias[21];
    char contrasena[21];
} Persona; 

// Cabeceras de funciones de login y registro
Persona loginAdmin();
Persona login();
Persona registro();

void abrirBaseDatos();
void cerrarBaseDatos();
void crearTablaUsuarios();
void insertarUsuario(Persona usuario);
Persona obtenerUsuarioPorAlias(const char* alias);

#endif
