#ifndef UTIL_H
#define UTIL_H

char* to_char_array(double num_double, int decimal_place);

#endif // UTIL_H
