#include <stdio.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include "../hFilesCliente/comunicacion.h"

#define PORT 8080

void sendCode(SOCKET sock, int code);
void receiveResponse(SOCKET sock);

int main() {
    WSADATA wsa;
    SOCKET sock;
    struct sockaddr_in serv_addr;
    char server_ip[16];  // Para almacenar la dirección IP ingresada


    // Inicializar Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        printf("Failed. Error Code : %d\n", WSAGetLastError());
        return 1;
    }

    // Crear socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        printf("Could not create socket : %d\n", WSAGetLastError());
        WSACleanup();
        return 1;
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Solicitar dirección IP del servidor
    printf("Ingrese la dirección IP del servidor: ");
    scanf("%15s", server_ip);

    // Convertir dirección IP a formato binario
    serv_addr.sin_addr.s_addr = inet_addr(server_ip);

    // Conectar al servidor
    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        printf("Connection Failed\n");
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    // Enviar y recibir datos secuencialmente
    sendCode(sock, MENU_INICIO);
    receiveResponse(sock);
    sendCode(sock, MENU_LOGIN);
    receiveResponse(sock);
    sendCode(sock, JUEGO_SIMON_SAYS);
    receiveResponse(sock);
    sendCode(sock, USUARIO_VERIFICAR);
    receiveResponse(sock);

    // Mantener la conexión abierta
    while (1) {
        char buffer[1024];
        int recv_size;

        // Recibir respuesta del servidor
        if ((recv_size = recv(sock, buffer, sizeof(buffer) - 1, 0)) == SOCKET_ERROR) {
            printf("recv failed\n");
            break;
        }
        buffer[recv_size] = '\0';
        printf("Respuesta del servidor: %s\n", buffer);
    }

    // Cerrar el socket
    closesocket(sock);
    WSACleanup();

    return 0;
}

void sendCode(SOCKET sock, int code) {
    int network_code = htonl(code);  // Convertir el código a orden de bytes de red
    if (send(sock, (const char*)&network_code, sizeof(network_code), 0) == SOCKET_ERROR) {
        printf("Send failed. Error Code : %d\n", WSAGetLastError());
    } else {
        printf("Codigo %d enviado\n", code);
    }
}

// en principio este ya no se usa
void receiveResponse(SOCKET sock) {
    char buffer[1024];
    int recv_size;

    // Recibir respuesta del servidor
    if ((recv_size = recv(sock, buffer, sizeof(buffer) - 1, 0)) == SOCKET_ERROR) {
        printf("recv failed. Error Code : %d\n", WSAGetLastError());
        return;
    }
    buffer[recv_size] = '\0';
    printf("Respuesta del servidor: %s\n", buffer);
}