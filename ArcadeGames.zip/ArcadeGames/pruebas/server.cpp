#include <iostream>
#include <cstring>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include "../hFilesServidor/sqlite3.h"
#include "../hFilesServidor/Usuario.h"
#include "../hFilesServidor/database.h"
#include "../hFilesCliente/comunicacion.h"

using namespace std;

#define PORT 8080
#define BUFFER_SIZE 1024

// Prototipos de las funciones que interactúan con la base de datos
void abrirBaseDatos();
void cerrarBaseDatos();
void insertarUsuario(Persona usuario);
Persona obtenerUsuarioPorAlias(const char* alias);
void insertarPuntuacion(Persona usuario, int codigo_juego, char* puntuacion);

void processClient(int clientSocket) {
    int command;
    int bytesReceived;
    char buffer[BUFFER_SIZE];

    while ((bytesReceived = recv(clientSocket, (char*)&command, sizeof(command), 0)) > 0) {
        command = ntohl(command);  // Convertir a orden de bytes de host
        cout << "Comando recibido: " << command << endl;

        switch (command) {
            case MENU_INICIO:
                send(clientSocket, "\n1. Registrarse\n2. Logearse\n3. Logear como admin\n4. Salir\nSeleccione una opcion: ", 
                    strlen("1. Registrarse\n2. Logearse\n3. Logear como admin\n4. Salir\nSeleccione una opcion: "), 0);
                if (strcmp((char*)&command, "1") == 0) {
                    send(clientSocket, "Opción 1 seleccionada: Registrarse\n", strlen("Opción 1 seleccionada: Registrarse\n"), 0);
                    // Aquí puedes añadir el código para manejar el registro
                } else if (strcmp((char*)&command, "2") == 0) {
                    send(clientSocket, "Opción 2 seleccionada: Logearse\n", strlen("Opción 2 seleccionada: Logearse\n"), 0);
                    // Aquí puedes añadir el código para manejar el login
                } else if (strcmp((char*)&command, "3") == 0) {
                    send(clientSocket, "Opción 3 seleccionada: Logear como admin\n", strlen("Opción 3 seleccionada: Logear como admin\n"), 0);
                    // Aquí puedes añadir el código para manejar el login de admin
                } else if (strcmp((char*)&command, "4") == 0) {
                    send(clientSocket, "Opción 4 seleccionada: Salir\n", strlen("Opción 4 seleccionada: Salir\n"), 0);
                    // Aquí puedes añadir el código para manejar la salida
                } else {
                    send(clientSocket, "Opción desconocida\n", strlen("Opción desconocida\n"), 0);
                }
            } else {
                cerr << "recv failed: " << strerror(errno) << endl;
            }
                break;
            case MENU_LOGIN:
                send(clientSocket, "MENU_LOGIN received", strlen("MENU_LOGIN received"), 0);
                break;
            case JUEGO_SIMON_SAYS:
                send(clientSocket, "JUEGO_SIMON_SAYS received", strlen("JUEGO_SIMON_SAYS received"), 0);
                break;
            case USUARIO_VERIFICAR:
                send(clientSocket, "USUARIO_VERIFICAR received", strlen("USUARIO_VERIFICAR received"), 0);
                break;
            default:
                send(clientSocket, "Unknown Command", strlen("Unknown Command"), 0);
                break;
        }
    }

    if (bytesReceived == 0) {
        cout << "Conexión cerrada por el cliente." << endl;
    } else {
        cerr << "recv failed: " << strerror(errno) << endl;
    }

    close(clientSocket);
}

int main() {
    int serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrSize = sizeof(clientAddr);

    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        cerr << "Error al abrir socket: " << strerror(errno) << endl;
        return -1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    if (bind(serverSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        cerr << "Bind failed: " << strerror(errno) << endl;
        close(serverSocket);
        return -1;
    }

    listen(serverSocket, 5);

    cout << "Servidor esperando conexiones en el puerto " << PORT << "..." << endl;

    while ((clientSocket = accept(serverSocket, (struct sockaddr *)&clientAddr, &clientAddrSize))) {
        cout << "Conexión establecida con " << inet_ntoa(clientAddr.sin_addr) << ":" << ntohs(clientAddr.sin_port) << endl;
        processClient(clientSocket);
    }

    if (clientSocket < 0) {
        cerr << "accept failed: " << strerror(errno) << endl;
        close(serverSocket);
        return -1;
    }

    close(serverSocket);
    return 0;
}