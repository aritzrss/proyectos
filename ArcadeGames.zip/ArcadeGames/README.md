Kaixo, debido a algunos problemas con sqlite y VSC no nos permite ejecutar debidamente el programa. Por lo que no podremos realizar las capturas para el word.
Te adjuntamos todo en lo que hemos trabajado hasta ahora, pero seguiremos trabajando para arreglar los problemas y que funcione todo bien. Esperamos poder arreglarlo de la manera mas breve posible.
De ser así, nos gustaria reenviarte el archivo con todos los datos actualizados, si se nos permite. Gracias por tu tiempo.
