#include <iostream>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include "../hFilesServidor/sqlite3.h"
#include "../hFilesServidor/Usuario.h"
#include "../hFilesServidor/database.h"
#include "../hFilesServidor/Menu.h"
#include "../hFilesServidor/log.h"

using namespace std;

void abrirBaseDatos();
void cerrarBaseDatos();
Persona registro();
Persona login();
void insertarPuntuacion(Persona usuario, int codigo_juego, char* puntuacion);
void inicializarBaseDatos();


void mostrarMenu() {
    cout << "Seleccione una opción:" << endl;
    cout << "1. Abrir base de datos" << endl;
    cout << "2. Cerrar base de datos" << endl;
    cout << "3. Registrar usuario" << endl;
    cout << "4. Iniciar sesión" << endl;
    cout << "5. Insertar puntuación" << endl;
    cout << "0. Salir" << endl;
}

int main() {
    int opcion;
    Persona usuario;
    int codigo_juego;
    char puntuacion[10];

    do {
        mostrarMenu();
        cin >> opcion;
        cin.ignore(); // Limpiar el buffer de entrada

        switch(opcion) {
            case 1:
                abrirBaseDatos();
                break;
            case 2:
                cerrarBaseDatos();
                break;
            case 3:
                usuario = registro();
                break;
            case 4:
                usuario = login();
                break;
            case 5:
                cout << "Ingrese el código del juego: ";
                cin >> codigo_juego;
                cout << "Ingrese la puntuación: ";
                cin >> puntuacion;
                usuario = login();
                if (strcmp(usuario.alias, "") != 0) {
                    insertarPuntuacion(usuario, codigo_juego, puntuacion);
                }
                break;
            case 0:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opción no válida. Por favor, intente de nuevo." << endl;
        }
    } while(opcion != 0);

    return 0;
}
