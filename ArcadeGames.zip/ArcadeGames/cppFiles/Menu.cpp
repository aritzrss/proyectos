#include "../hFilesServidor/Usuario.h"
#include <iostream>
#include "../hFilesServidor/golpeaAlTopo.h"
#include "../hFilesServidor/simon.h"
#include "../hFilesServidor/tiempoReaccion.h"
#include "../hFilesServidor/Menu.h"
#include "../hFilesServidor/comunicacion.h"
#include <arpa/inet.h>
#include <cstring> // Incluir para strlen y strcmp

using namespace std;
#define BUFFER_SIZE 1024


void mostrarMenuPrincipal(Persona usuario, int command, int clientSocket) {
    send(clientSocket, "\n1. Tiempo de reaccion\n2. Simon dice\n3. Golpea al topo\n4. Salir\nSeleccione una opcion: ", 
        strlen("\n1. Tiempo de reaccion\n2. Simon dice\n3. Golpea al topo\n4. Salir\nSeleccione una opcion: "), 0);
}

void mostrarOpcionesJuego(Persona usuario, int command, int clientSocket) {
    send(clientSocket, "\n1. Historial de puntuaciones del usuario\n2. Historial de puntuaciones del juego\n3. Jugar\n 4. Salir\nSeleccione una opcion: ", 
        strlen("\n1. Historial de puntuaciones del usuario\n2. Historial de puntuaciones del juego\n3. Jugar\n 4. Salir\nSeleccione una opcion: "), 0);

}

void mostrarMenuInicio(int command, int clientSocket) {
    cout << "En el inicio de mostrar menu: " <<command<<endl;

    send(clientSocket, "\n1. Registrarse\n2. Logearse\n3. Logear como admin\n4. Salir\nSeleccione una opcion: ", 
        strlen("\n1. Registrarse\n2. Logearse\n3. Logear como admin\n4. Salir\nSeleccione una opcion: "), 0);

}

void mostrarDificultadesTopo(Persona usuario, int command, int clientSocket){
    send(clientSocket, "\n1. Dificultad Facil\n2. Dificultad Normal\n3. Dificultad Dificil\n4. Salir\nSeleccione una opcion: ", 
        strlen("\n1. Dificultad Facil\n2. Dificultad Normal\n3. Dificultad Dificil\n4. Salir\nSeleccione una opcion: "), 0);
}
