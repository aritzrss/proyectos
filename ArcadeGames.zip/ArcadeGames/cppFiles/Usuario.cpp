
#include "../hFilesServidor/Usuario.h"
#include <iostream>
#include <string.h>

using namespace std;

Persona loginAdmin() {
    Persona p;
    strcpy(p.alias, "admin");
    strcpy(p.contrasena, "admin");
    return p;
}

Persona login(){
    abrirBaseDatos();
    char alias[21];
    char contrasena[21];

    cout << "Ingrese su alias: " << endl;
    cin >> alias;
    cout << "Ingrese su contraseña: " << endl;
    cin >> contrasena;

    Persona usuario = obtenerUsuarioPorAlias(alias);
    
    if (strcmp(usuario.contrasena, contrasena) == 0) {
        cout << "Inicio de sesión exitoso. Bienvenido, " << usuario.alias << endl;
    } else {
        cout << "Datos incorrectos. Por favor, inténtelo de nuevo." << endl;
        strcpy(usuario.alias, "");
    }

    cerrarBaseDatos();
    return usuario;
}

Persona registro() {
    abrirBaseDatos();
    Persona usuario;

    cout << "Ingrese su alias: " << endl;
    cin >> usuario.alias;
    cout << "Ingrese su contraseña: " << endl;
    cin >> usuario.contrasena;

    insertarUsuario(usuario);

    cout << "Registro exitoso. Bienvenido, " << usuario.alias << endl;

    cerrarBaseDatos();
    return usuario;
}