#include "../hFilesServidor/sqliteWrapper.h"
#include <iostream>

using namespace std;

SQLiteWrapper::SQLiteWrapper(const string& dbFileName) {
    int rc = sqlite3_open(dbFileName.c_str(), &db);
    if (rc) {
        std::cerr << "No se puede abrir la base de datos: " << sqlite3_errmsg(db) << endl;
        db = nullptr;
    } else {
        cout << "Base de datos abierto correctamente." << endl;
    }
}

SQLiteWrapper::~SQLiteWrapper() {
    if (db) {
        sqlite3_close(db);
    }
}

bool SQLiteWrapper::execute(const string& sql) {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sql.c_str(), nullptr, 0, &errMsg);
    if (rc != SQLITE_OK) {
        cerr << "SQL error: " << errMsg << endl;
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}

bool SQLiteWrapper::query(const string& sql, int (*callback)(void*, int, char**, char**), void* data) {
    char* errMsg = nullptr;
    int rc = sqlite3_exec(db, sql.c_str(), callback, data, &errMsg);
    if (rc != SQLITE_OK) {
        cerr << "SQL error: " << errMsg << endl;
        sqlite3_free(errMsg);
        return false;
    }
    return true;
}