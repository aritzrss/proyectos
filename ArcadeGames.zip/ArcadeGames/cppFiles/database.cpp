#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <ctime>
#include <sys/stat.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include "../hFilesServidor/sqlite3.h"
#include "../hFilesServidor/Usuario.h"
#include "../hFilesServidor/database.h"
#include "../hFilesServidor/Menu.h"
#include "../hFilesServidor/log.h"
#include "../hFilesServidor/comunicacion.h"
#include <vector>
#include <unistd.h>
#include <sys/socket.h>
#include <sqlite3.h>


using namespace std;

sqlite3 *db = nullptr; // Definición única

void inicializarBaseDatos() {
    const char *sql_usuario = "CREATE TABLE IF NOT EXISTS USUARIO ("
                              "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                              "alias TEXT NOT NULL UNIQUE, "
                              "contrasena TEXT NOT NULL);";

    char *errMsg = nullptr;
    int rc = sqlite3_exec(db, sql_usuario, 0, 0, &errMsg);

    if (rc != SQLITE_OK) {
        cerr << "Error al crear la tabla USUARIO: " << errMsg << endl;
        sqlite3_free(errMsg);
        exit(1);
    }

    const char *sql_modoJ = "CREATE TABLE IF NOT EXISTS MODO_JUEGO ("
                                 "id_modo INTEGER PRIMARY KEY AUTOINCREMENT, "
                                 "juego TEXT NOT NULL);";

    rc = sqlite3_exec(db, sql_modoJ, 0, 0, &errMsg);

    if (rc != SQLITE_OK) {
        cerr << "Error al crear la tabla modo_juego: " << errMsg << endl;
        sqlite3_free(errMsg);
        exit(1);
    }

    const char *sql_tipo_puntuacion = "CREATE TABLE IF NOT EXISTS TIPO_PUNTUACION ("
                                 "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                 "tipo_punt TEXT NOT NULL);";

    rc = sqlite3_exec(db, sql_tipo_puntuacion, 0, 0, &errMsg);

    if (rc != SQLITE_OK) {
        cerr << "Error al crear la tabla TIPO_PUNTUACION: " << errMsg << endl;
        sqlite3_free(errMsg);
        exit(1);
    }

     const char *sql_puntuacion = "CREATE TABLE IF NOT EXISTS PUNTUACION ("
                                 "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                 "fecha TEXT NOT NULL, "
                                 "puntuacion TEXT NOT NULL, "
                                 "id_usu INTEGER NOT NULL, "
                                 "id_modo INTEGER NOT NULL, "
                                 "id_tipo INTEGER NOT NULL, "
                                 "FOREIGN KEY(id_usu) REFERENCES USUARIO(id));";

    rc = sqlite3_exec(db, sql_puntuacion, 0, 0, &errMsg);

    if (rc != SQLITE_OK) {
        cerr << "Error al crear la tabla PUNTUACION: " << errMsg << endl;
        sqlite3_free(errMsg);
        exit(1);
    }

    
}


void abrirBaseDatos() {
    const char *ruta_base_datos = "ArcadeGames/ArcadeBBDD.db";
    const char *directorio = "ArcadeGames";

    // Verifica si el directorio existe, si no, lo crea
    struct stat info;
    if (stat(directorio, &info) != 0) {
        // El directorio no existe, intenta crearlo
        if (mkdir(directorio, 0777) != 0) {
            cerr << "Error al crear el directorio: " << strerror(errno) << endl;
            exit(1);
        }
    } else if (!(info.st_mode & S_IFDIR)) {
        cerr << "El camino existe pero no es un directorio" << endl;
        exit(1);
    }

    // Intentar abrir la base de datos
    int rc = sqlite3_open(ruta_base_datos, &db);
    if (rc != SQLITE_OK) {
        cerr << "Error al abrir la base de datos: " << sqlite3_errmsg(db) << endl;
        exit(1);
    } else {
        cout << "Base de datos abierta exitosamente" << endl;
    }

    inicializarBaseDatos();
}

void cerrarBaseDatos() {
    sqlite3_close(db);
    cout << "Base de datos cerrada exitosamente" << endl;
}

void insertarUsuario(Persona usuario) {
    const char *sql = "INSERT INTO USUARIO (alias, contrasena) VALUES (?, ?);";

    sqlite3_stmt *stmt;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    if (rc == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, usuario.alias, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, usuario.contrasena, -1, SQLITE_STATIC);

        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
        cout << "Usuario insertado exitosamente" << endl;
    } else {
        cerr << "Error al insertar usuario: " << sqlite3_errmsg(db) << endl;
    }
}

int findIdUsu(Persona usuario) {
    char id[10];
    const char *sql = "SELECT id FROM USUARIO WHERE alias = ?;";

    sqlite3_stmt *stmt;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    if (rc == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, usuario.alias, -1, SQLITE_STATIC);

        if (sqlite3_step(stmt) == SQLITE_ROW) {
            strcpy(id, (const char *)sqlite3_column_text(stmt, 0));
        }

        sqlite3_finalize(stmt);
    } else {
        cerr << "Error al obtener usuario: " << sqlite3_errmsg(db) << endl;
    }

    return atoi(id);
}

void insertarPuntuacion(Persona usuario, int codigo_juego, char* puntuacion) {
    const char *sql = "INSERT INTO PUNTUACION (fecha, puntuacion, id_usu, id_modo, id_tipo) VALUES (?, ?, ?, ?, ?);";

    sqlite3_stmt *stmt;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    time_t t = time(NULL);
    struct tm tiempoLocal = *localtime(&t);
    char fechaHora[70];
    const char *formato = "%Y-%m-%d %H:%M:%S";
    strftime(fechaHora, sizeof(fechaHora), formato, &tiempoLocal);

    if (rc == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, fechaHora, -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, puntuacion, -1, SQLITE_STATIC);

        int id_usu = findIdUsu(usuario);
        sqlite3_bind_int(stmt, 3, id_usu);
        sqlite3_bind_int(stmt, 4, codigo_juego);
        sqlite3_bind_int(stmt, 5, codigo_juego);

        sqlite3_step(stmt);
        sqlite3_finalize(stmt);
        cout << "Puntuacion guardada exitosamente" << endl;
    } else {
        cerr << "Error al guardar puntuacion: " << sqlite3_errmsg(db) << endl;
    }
}

Persona obtenerUsuarioPorAlias(const char *alias) {
    Persona usuario;
    const char *sql = "SELECT * FROM USUARIO WHERE alias = ?;";

    sqlite3_stmt *stmt;
    int rc = sqlite3_prepare_v2(db, sql, -1, &stmt, 0);

    if (rc == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, alias, -1, SQLITE_STATIC);

        if (sqlite3_step(stmt) == SQLITE_ROW) {
            strcpy(usuario.alias, (const char *)sqlite3_column_text(stmt, 1));
            strcpy(usuario.contrasena, (const char *)sqlite3_column_text(stmt, 2));
        }

        sqlite3_finalize(stmt);
    } else {
        cerr << "Error al obtener usuario: " << sqlite3_errmsg(db) << endl;
    }

    return usuario;
}

vector<Puntuacion> obtenerTopPuntuaciones(int codigoJuego, sqlite3* db) {
    std::vector<Puntuacion> puntuaciones;
    sqlite3_stmt* stmt;
    const char* sql = "SELECT U.Alias, P.Puntuacion, P.Fecha FROM PUNTUACION P "
                      "JOIN USUARIO U ON P.Id_Usu = U.Id_Usu "
                      "WHERE P.Id_Modo = ? ORDER BY P.Puntuacion DESC LIMIT 10";

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, codigoJuego);

        while (sqlite3_step(stmt) == SQLITE_ROW) {
            Puntuacion puntuacion;
            puntuacion.alias = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
            puntuacion.puntuacion = sqlite3_column_double(stmt, 1);
            puntuacion.fecha = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
            puntuaciones.push_back(puntuacion);
        }
    }
    sqlite3_finalize(stmt);
    return puntuaciones;
}

void enviarPuntuaciones(const std::vector<Puntuacion>& puntuaciones, int clienteSocket) {
    std::string mensaje;
    for (size_t i = 0; i < puntuaciones.size(); ++i) {
        mensaje += std::to_string(i + 1) + ". " + puntuaciones[i].alias + " - " +
                   std::to_string(puntuaciones[i].puntuacion) + " - " +
                   puntuaciones[i].fecha + "\n";
    }
    send(clienteSocket, mensaje.c_str(), mensaje.size(), 0);
}

std::vector<Puntuacion> obtenerTopPuntuacionesUsuario(Persona usuario, sqlite3* db) {
    std::vector<Puntuacion> puntuaciones;
    sqlite3_stmt* stmt;
    const char* sql = "SELECT U.alias, P.puntuacion, P.fecha FROM PUNTUACION P "
                      "JOIN USUARIO U ON P.Id_Usu = U.Id_Usu "
                      "WHERE P.Id_Usu = ? ORDER BY P.puntuacion DESC LIMIT 10";

    int usuarioId = findIdUsu(usuario);

    if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, usuarioId);

        while (sqlite3_step(stmt) == SQLITE_ROW) {
            Puntuacion puntuacion;
            puntuacion.alias = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
            puntuacion.puntuacion = sqlite3_column_double(stmt, 1);
            puntuacion.fecha = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
            puntuaciones.push_back(puntuacion);
        }
    } else {
        std::cerr << "Error en la preparación de la consulta SQL: " << sqlite3_errmsg(db) << std::endl;
    }
    sqlite3_finalize(stmt);
    return puntuaciones;
}

void mostrarPuntuacionesJuego(int codigo, int clienteSocket){

    int codigo_sql;

    switch (codigo){
        case SOLICITUD_MEJORES_PUNTUACIONES_REACCION:{
            codigo_sql = 1;
        }
        
        case SOLICITUD_MEJORES_PUNTUACIONES_SIMON:{
            codigo_sql = 2;
        }
        
        case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_D:{
            codigo_sql = 5;
        }

        case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_F:{
            codigo_sql = 3;
        }

        case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_M:{
            codigo_sql = 4;
        }

        default:{
        }
    }

    vector<Puntuacion> puntuaciones = obtenerTopPuntuaciones(codigo_sql, db);
    enviarPuntuaciones(puntuaciones, clienteSocket);

}


void mostrarPuntuacionesUsuario(Persona usuario, int codigo, int clienteSocket){

    int codigo_sql;

    switch (codigo){
        case SOLICITUD_MEJORES_PUNTUACIONES_REACCION:{
            codigo_sql = 1;
        }
        
        case SOLICITUD_MEJORES_PUNTUACIONES_SIMON:{
            codigo_sql = 2;
        }
        
        case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_D:{
            codigo_sql = 5;
        }

        case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_F:{
            codigo_sql = 3;
        }

        case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_M:{
            codigo_sql = 4;
        }

        default:{
        }
    }

    std::vector<Puntuacion> puntuaciones = obtenerTopPuntuacionesUsuario(usuario, db);
    enviarPuntuaciones(puntuaciones, clienteSocket);

}