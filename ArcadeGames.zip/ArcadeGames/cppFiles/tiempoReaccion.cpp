#include "../hFilesServidor/tiempoReaccion.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <unistd.h> // Para usleep
#include <termios.h> // Para getch y kbhit
#include <fcntl.h> // Para kbhit
#include "../hFilesServidor/database.h" //hay que guardar la puntuacion cuando termine el juego
#include "../hFilesServidor/util.h"

using namespace std;

int codigo_juego_tiempo = 1;

void encenderLED(int led) {
    switch (led) {
        case 1:
            // Encender LED 1
            break;
        case 2:
            // Encender LED 2
            break;
        case 3:
            // Encender LED 3
            break;
    }
}

void apagarLEDs() {
    // Apagar todos los LEDs
}

int getch() {
    struct termios oldt, newt;
    int ch;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return ch;
}

int kbhit() {
    struct termios oldt, newt;
    int ch;
    int oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if(ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

void reaccion(Persona usuario) {
    int tiempoEncendido = rand() % 2000 + 1000; // Tiempo en milisegundos que permanecen encendidos los LEDs
    int numLEDs = 3; // Número de LEDs

    cout << "Presiona cualquier tecla para empezar..." << endl;
    getch();

    while (1) {
        // Mostrar patrón de LEDs
        for (int i = 1; i <= numLEDs; i++) {
            encenderLED(i);
            usleep(tiempoEncendido * 1000);
            apagarLEDs();
        }

        // Esperar a que el jugador presione la barra espaciadora
        clock_t inicio = clock();
        cout << "¡Presiona la barra espaciadora!" << endl;
        while (!kbhit());
        clock_t fin = clock();

        double tiempoReaccion = static_cast<double>(fin - inicio) / CLOCKS_PER_SEC * 1000;

        cout << "Tu tiempo de reaccion fue: " << tiempoReaccion << " milisegundos" << endl;

        insertarPuntuacion(usuario, codigo_juego_tiempo, to_char_array(tiempoReaccion, 3));

        cout << endl << "¿Quieres jugar de nuevo? (s/n): " << endl;
        if (getch() != 's') {
            reaccion(usuario);
        } else {
            break;
        }
    }
}
