#include <iostream>
#include <cstdarg>
#include <cstdlib>
#include <ctime>
#include "../hFilesServidor/log.h"

using namespace std;

// Función para obtener la marca de tiempo actual
char* get_timestamp() {
    time_t rawtime;
    struct tm *timeinfo;
    char *timestamp = (char *)malloc(20 * sizeof(char)); // Reserva memoria para la marca de tiempo
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(timestamp, 20, "%Y-%m-%d %H:%M:%S", timeinfo);
    return timestamp;
}

// Función para escribir un mensaje de registro
void log_message(LogLevel level, const char *format, ...) {
    va_list args;
    va_start(args, format);

    const char *level_str;
    switch (level) {
        case INFO:
            level_str = "INFO";
            break;
        case DEBUG:
            level_str = "DEBUG";
            break;
        case WARNING:
            level_str = "WARNING";
            break;
        case ERROR:
            level_str = "ERROR";
            break;
        default:
            level_str = "UNKNOWN";
    }

    cout << "[" << get_timestamp() << "] [" << level_str << "]: ";
    vprintf(format, args); // Imprime el mensaje formateado
    cout << endl;

    va_end(args);
}