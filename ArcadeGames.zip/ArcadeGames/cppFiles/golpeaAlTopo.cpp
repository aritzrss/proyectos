#include "../hFilesServidor/golpeaAlTopo.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <unistd.h> // Para usleep
#include "../hFilesServidor/database.h"  //hay que guardar la puntuacion cuando termine el juego

using namespace std;

int codigo_juego_topo = 0;


void juegoGolpeaAlTopo(Persona usuario, int dificultad) {
    int vidas = 3;
    int aciertos = 0;
    float tiempoEspera = 2000; // Esto ajustarlo dependiendo de la dificultad.

    // Ajustes al inicio dependiendo de la dificultad escogida.
    switch(dificultad) {
        case 1: tiempoEspera = 2000; break; // Fácil
        case 2: tiempoEspera = 1500; break; // Medio
        case 3: tiempoEspera = 1000; break; // Difícil
    }

    cout << "Inicio del juego. Tienes " << vidas << " vidas" << endl;

    while(vidas > 0) {
        cout << "Encendiendo LEDs..." << endl;
        // encenderLed(ledAleatoria); // Simulación, deberíamos implementar esto en C++.

        usleep(tiempoEspera * 1000); // Espera activa.

        // Será necesario que verifiquemos que el jugador ha reaccionado a tiempo y ajustar vidas/aciertos.

        // Ajuste del tiempo basado en aciertos y dificultad.
        if((dificultad == 1 && aciertos % 5 == 0) ||
           (dificultad == 2 && aciertos % 4 == 0) ||
           (dificultad == 3 && aciertos % 3 == 0)) {
            tiempoEspera -= 500; // Disminución de 0.5 segundos
            if(tiempoEspera < 500) tiempoEspera = 500; // Límite mínimo.
        }
    }

    cout << "Juego terminado. Tu puntuación fue: " << aciertos << endl;
    insertarPuntuacion(usuario, codigo_juego_topo, const_cast<char*>(std::to_string(aciertos).c_str()));
}

