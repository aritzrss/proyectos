#include "../hFilesServidor/Menu.h"
#include "../hFilesServidor/Usuario.h"
#include "../hFilesServidor/log.h"
#include "../hFilesServidor/sqlite3.h"
#include "../hFilesServidor/database.h"
#include "../hFilesServidor/simon.h"
#include "../hFilesServidor/tiempoReaccion.h"
#include "../hFilesServidor/golpeaAlTopo.h"
#include <iostream>
#include <cstring>
#include <string>
#include <unistd.h>
#include <arpa/inet.h>
#include "../hFilesServidor/comunicacion.h"

//g++ cppFiles/main.cpp cppFiles/Menu.cpp cppFiles/Usuario.cpp cppFiles/log.cpp cppFiles/database.cpp cppFiles/util.cpp -o server -lsqlite3

using namespace std;

#define PORT 8080
#define BUFFER_SIZE 1024

void sendCode(int sock, int code) {
    send(sock, (const char*)&code, sizeof(code), 0);
    printf("Codigo %d enviado\n", code);
}

void debugReceive(int sock, char *buffer, int size) {
    int bytesReceived = recv(sock, buffer, size, 0);
    if (bytesReceived == -1) {
        perror("Error recibiendo datos");
    } else {
        buffer[bytesReceived] = '\0'; // Null-terminate the buffer
        std::cout << "Datos recibidos: " << buffer << std::endl;
    }
}

// Prototipos de las funciones que interactúan con la base de datos
void abrirBaseDatos();
void cerrarBaseDatos();
void insertarUsuario(Persona usuario);
Persona obtenerUsuarioPorAlias(const char* alias);
void insertarPuntuacion(Persona usuario, int codigo_juego, char* puntuacion);
int simon(Persona usuario, int moves, int lives, int score);

void processClient(int clientSocket) {
    int command;
    int bytesReceived;
    char buffer[BUFFER_SIZE];
    Persona usuarioActual;
    Persona userRecuperado;
    int juegoAc;

    while ((bytesReceived = recv(clientSocket, (char*)&command, sizeof(command), 0)) > 0) {
        cout << "Comando recibido: " << command << endl;

        switch (command) {
            case MENU_INICIO:
                mostrarMenuInicio(command, clientSocket);
                break;

            case MENU_LOGIN_ALIAS:
                cout << "entro en menu login alias" << endl;
                send(clientSocket, "Indique su alias: \n", strlen("Indique su alias: \n"), 0);
                break;

            case MENU_LOGIN_CLAVE:
                send(clientSocket, "Indique su clave: \n", strlen("Indique su clave: \n"), 0);
                break;

            case MENU_REGISTRO_ALIAS:
                send(clientSocket, "Indique su alias: \n", strlen("Indique su alias: \n"), 0);
                break;

            case MENU_REGISTRO_CLAVE:
                send(clientSocket, "Indique su clave: \n", strlen("Indique su clave: \n"), 0);
                break;

            case ENVIO_ALIAS_LOGIN: {
                char alias[21];

                std::cout << "Código recibido: " << command << std::endl;

                int alias_len = recv(clientSocket, alias, sizeof(alias) - 1, 0);
                if (alias_len == -1) {
                    perror("Error recibiendo el alias");
                    return;
                }
                alias[alias_len] = '\0';
                strncpy(usuarioActual.alias, alias, sizeof(usuarioActual.alias) - 1);
                usuarioActual.alias[sizeof(usuarioActual.alias) - 1] = '\0';
                std::cout << "Alias recibido: " << alias << std::endl;
                send(clientSocket, "Alias confirmado\n", strlen("Alias confirmado.\n"), 0);
                break;
            }
            case ENVIO_ALIAS_REGISTRO: {
                char alias[21];

                std::cout << "Código recibido: " << command << std::endl;

                int alias_len = recv(clientSocket, alias, sizeof(alias) - 1, 0);
                if (alias_len == -1) {
                    perror("Error recibiendo el alias");
                    return;
                }
                alias[alias_len] = '\0';
                strncpy(usuarioActual.alias, alias, sizeof(usuarioActual.alias) - 1);
                usuarioActual.alias[sizeof(usuarioActual.alias) - 1] = '\0';
                std::cout << "Alias recibido: " << alias << std::endl;
                send(clientSocket, "Confirmado.\n", strlen("Confirmado.\n"), 0);
                break;
            }
            case ENVIO_CONTRASENYA_REGISTRO: {
                char contrasena[21];

                std::cout << "Código recibido: " << command << std::endl;

                int contrasena_len = recv(clientSocket, contrasena, sizeof(contrasena) - 1, 0);
                if (contrasena_len == -1) {
                    perror("Error recibiendo la contrasena");
                    return;
                }
                contrasena[contrasena_len] = '\0';
                strncpy(usuarioActual.contrasena, contrasena, sizeof(usuarioActual.contrasena) - 1);
                usuarioActual.contrasena[sizeof(usuarioActual.contrasena) - 1] = '\0';
                std::cout << "Contrasena recibida: " << contrasena << std::endl;

                userRecuperado = obtenerUsuarioPorAlias(usuarioActual.alias);

                if (strcmp(userRecuperado.alias, usuarioActual.alias) == 0) {
                    if (strcmp(userRecuperado.contrasena, usuarioActual.contrasena) == 0) {
                        sendCode(clientSocket, CONFIRMACION_LOGIN);
                        memset(buffer, '\0', BUFFER_SIZE);
                    } else {
                        sendCode(clientSocket, ERROR_CONTRASENYA_REGISTRO);
                        memset(buffer, '\0', BUFFER_SIZE);
                    }
                } else {
                    send(clientSocket, "Contraseña registrada.\n", strlen("Contraseña registrada.\n"), 0);
                    memset(buffer, '\0', BUFFER_SIZE);
                }
                break;
            }
            case ENVIO_CONTRASENYA_LOGIN: {
                char contrasena[21];

                std::cout << "Código recibido: " << command << std::endl;

                int contrasena_len = recv(clientSocket, contrasena, sizeof(contrasena) - 1, 0);
                if (contrasena_len == -1) {
                    perror("Error recibiendo la contrasena");
                    return;
                }
                contrasena[contrasena_len] = '\0';
                strncpy(usuarioActual.contrasena, contrasena, sizeof(usuarioActual.contrasena) - 1);
                usuarioActual.contrasena[sizeof(usuarioActual.contrasena) - 1] = '\0';
                std::cout << "Contrasena recibida: " << contrasena << std::endl;

                userRecuperado = obtenerUsuarioPorAlias(usuarioActual.alias);

                if (strcmp(userRecuperado.alias, usuarioActual.alias) == 0) {
                    if (strcmp(userRecuperado.contrasena, usuarioActual.contrasena) == 0) {
                        sendCode(clientSocket, CONFIRMACION_LOGIN);
                        memset(buffer, '\0', BUFFER_SIZE);
                    } else {
                        sendCode(clientSocket, ERROR_CONTRASENYA_LOGIN);
                        memset(buffer, '\0', BUFFER_SIZE);
                    }
                } else {
                    sendCode(clientSocket, ERROR_ALIAS_LOGIN);
                    memset(buffer, '\0', BUFFER_SIZE);
                }
                break;
            }
            case MENU_ADMIN:
                strncpy(usuarioActual.alias, "admin", sizeof(usuarioActual.alias) - 1);
                usuarioActual.alias[sizeof(usuarioActual.alias) - 1] = '\0';
                strncpy(usuarioActual.contrasena, "admin", sizeof(usuarioActual.contrasena) - 1);
                usuarioActual.contrasena[sizeof(usuarioActual.contrasena) - 1] = '\0';
                break;

            case MENU_PRINCIPAL:
                mostrarMenuPrincipal(usuarioActual, command, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case MENU_OPCIONES_JUEGO:
                mostrarOpcionesJuego(usuarioActual, command, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case MENU_DIFICULTADES_TOPO:
                mostrarDificultadesTopo(usuarioActual, command, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case DIFICULTAD_DIFICIL:
                juegoGolpeaAlTopo(usuarioActual, 3);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case DIFICULTAD_FACIL:
                juegoGolpeaAlTopo(usuarioActual, 1);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case DIFICULTAD_NORMAL:
                juegoGolpeaAlTopo(usuarioActual, 2);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case JUEGO_TIEMPO_REACCION:
                reaccion(usuarioActual);
                break;

            case JUEGO_SIMON_SAYS:
                juegoAc = simon(usuarioActual, 1, 3, 0);
                break;

            case SOLICITUD_MEJORES_PUNTUACIONES_REACCION:
                mostrarPuntuacionesJuego(SOLICITUD_MEJORES_PUNTUACIONES_REACCION, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_MEJORES_PUNTUACIONES_SIMON:
                mostrarPuntuacionesJuego(SOLICITUD_MEJORES_PUNTUACIONES_SIMON, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_D:
                mostrarPuntuacionesJuego(SOLICITUD_MEJORES_PUNTUACIONES_TOPO_D, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_F:
                mostrarPuntuacionesJuego(SOLICITUD_MEJORES_PUNTUACIONES_TOPO_F, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_MEJORES_PUNTUACIONES_TOPO_M:
                mostrarPuntuacionesJuego(SOLICITUD_MEJORES_PUNTUACIONES_TOPO_M, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_PUNTUACIONES_USUARIO_REACCION:
                mostrarPuntuacionesUsuario(usuarioActual, SOLICITUD_PUNTUACIONES_USUARIO_REACCION, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_PUNTUACIONES_USUARIO_SIMON:
                mostrarPuntuacionesUsuario(usuarioActual, SOLICITUD_PUNTUACIONES_USUARIO_SIMON, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_PUNTUACIONES_USUARIO_TOPO_D:
                mostrarPuntuacionesUsuario(usuarioActual, SOLICITUD_PUNTUACIONES_USUARIO_TOPO_D, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_PUNTUACIONES_USUARIO_TOPO_F:
                mostrarPuntuacionesUsuario(usuarioActual, SOLICITUD_PUNTUACIONES_USUARIO_TOPO_F, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            case SOLICITUD_PUNTUACIONES_USUARIO_TOPO_M:
                mostrarPuntuacionesUsuario(usuarioActual, SOLICITUD_PUNTUACIONES_USUARIO_TOPO_M, clientSocket);
                memset(buffer, '\0', BUFFER_SIZE);
                break;

            default:
                send(clientSocket, "Unknown Command\n", strlen("Unknown Command\n"), 0);
                memset(buffer, '\0', BUFFER_SIZE);
                break;
        }
    }

    if (bytesReceived == 0) {
        cout << "Conexión cerrada por el cliente." << endl;
    } else if (bytesReceived == -1) {
        cerr << "recv failed: " << strerror(errno) << endl;
    }

    close(clientSocket);
}

int main() {
    log_message(INFO, "Este es un mensaje de información");
    log_message(DEBUG, "Este es un mensaje de depuración");
    log_message(WARNING, "Este es un mensaje de advertencia");
    log_message(ERROR, "Este es un mensaje de error");

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        perror("setsockopt");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("listen");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
        perror("accept");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    processClient(new_socket);

    close(server_fd);
    return 0;
}
