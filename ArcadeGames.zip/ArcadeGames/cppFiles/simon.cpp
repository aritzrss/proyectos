#include <iostream>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <cmath> // Para pow y round
#include "../hFilesServidor/Usuario.h"
#include "../hFilesServidor/simon.h"
#include "../hFilesServidor/database.h"  // hay que guardar la puntuacion cuando termine el juego
#include "../hFilesServidor/util.h"

using namespace std;

const int max_moves = 32;
int codigo_juego_simon = 2;
int posicion_led = 0;

int* sequence = (int*) malloc(sizeof(int) * max_moves);
int* player_sequence = (int*) malloc(sizeof(int) * max_moves);

int rand_range(int min, int max) {
    return min + rand() / (RAND_MAX / (max - min + 1) + 1);
}

void print_instructions() {
    cout << "Simon dice: sigue la secuencia de colores que te muestro." << endl;
    cout << "Los colores son: " << endl;
    cout << "1 - Rojo" << endl;
    cout << "2 - Verde" << endl;
    cout << "3 - Azul" << endl;
    cout << "4 - Amarillo" << endl;
    cout << "Para responder, ingresa la secuencia completa de números sin espacios." << endl;
}

void generate_display_sequence(int sequence[], int length) {
    for (posicion_led; posicion_led < length; posicion_led++) {
        sequence[posicion_led] = rand_range(1, 4); // Cambié el rango a 1-4 para coincidir con los colores
    }
}

void get_player_input(int player_sequence[], int length) {
    cout << "Ingresa la secuencia: ";
    for (int i = 0; i < length; i++) {
        cin >> player_sequence[i];
    }
    //en vez de cin, habra que usar los sockets, o combinarlos
}

int compare_sequences(int sequence[], int player_sequence[], int length) {
    for (int i = 0; i < length; i++) {
        if (sequence[i] != player_sequence[i]) {
            return 0;
        }
    }
    return 1;
}

int simon(Persona usuario, int moves, int lives, int score) {
    srand(time(NULL));

    print_instructions();

    while (lives > 0 && moves <= max_moves) {
        generate_display_sequence(sequence, moves);

        // Simular mostrar la secuencia al jugador
        for (int i = 0; i < moves; i++) {
            cout << "LED " << sequence[i] << " encendido." << endl;
            usleep(500000); // Espera 0.5 segundos para simular el encendido de un LED
            cout << "LED " << sequence[i] << " apagado." << endl;
            usleep(500000); // Espera 0.5 segundos para simular el apagado de un LED
        }

        get_player_input(player_sequence, moves);

        if (compare_sequences(sequence, player_sequence, moves)) {
            cout << "¡Correcto!" << endl;
            score++;
            moves++; // Incrementa la longitud de la secuencia solo si es correcto
        } else {
            cout << "Incorrecto. Te quedan " << --lives << " vidas." << endl;
            if (lives == 0) {
                cout << "Fin del juego. Puntuación: " << score << endl;
                // Aquí se puede guardar la puntuación en la base de datos
                insertarPuntuacion(usuario, codigo_juego_simon, to_char_array(score, 0));
                break;
            } else {
                simon(usuario, moves, lives, score);
            }
        }   
    }

    return 0;
}
